#!/bin/bash

#SBATCH --nodes=1
#SBATCH --time=00:10:00
#SBATCH --job-name=fsdax_ior
#SBATCH --nvram-option=1LM:1000
#SBATCH -o /home/nx01/nx01/adrianj/IOR/fsdax_ior.%A.out
#SBATCH -e /home/nx01/nx01/adrianj/IOR/fsdax_ior.%A.err
#SBATCH --cpus-per-task=1

export NODES=1
export NPROCS=48

export PSM2_MULTIRAIL=1
export PSM2_MULTIRAIL_MAP=0:1,1:1
export PSM2_MULTI_EP=1
export PSM2_DEVICES="self,hfi,shm"
export I_MPI_HYDRA_TOPOLIB=

cd /lustre/home/nx01/nx01/adrianj/IOR/

export OMP_NUM_THREADS=1

cp test.script.easy.fsdax test.script

srun -n ${NODES} -N ${NODES} mkdir /mnt/pmem_fsdax0/data
srun -n ${NODES} -N ${NODES} mkdir /mnt/pmem_fsdax1/data

mpirun -n ${NPROCS} -ppn 48 /lustre/home/nx01/nx01/adrianj/IOR/src/C/IOR -vvv -b 2g -f /lustre/home/nx01/nx01/adrianj/IOR/test.script

srun -n ${NODES} -N ${NODES} rm -fr /mnt/pmem_fsdax0/data
srun -n ${NODES} -N ${NODES} rm -fr /mnt/pmem_fsdax1/data

