#!/bin/bash

#SBATCH --nodes=1
#SBATCH --time=00:10:00
#SBATCH --job-name=gkfs_ior
#SBATCH --nvram-option=1LM:1000
#SBATCH --filesystem-type=gekkofs
#SBATCH --filesystem-device=/mnt/pmem_fsdax0/
#SBATCH --filesystem-mountpoint=/home/nx01/nx01/adrianj/IOR/gkfs_mnt
#SBATCH -o /home/nx01/nx01/adrianj/IOR/gkfs_ior.%A.out
#SBATCH -e /home/nx01/nx01/adrianj/IOR/gkfs_ior.%A.err

module use /home/nx01/shared/GekkoFS-BSC/modules/
module load GekkoFS/latest

cp test.script.hard test.script

export PSM2_MULTIRAIL=1
export PSM2_MULTIRAIL_MAP=0:1,1:1
export PSM2_MULTI_EP=1
export PSM2_DEVICES="self,hfi,shm"
export I_MPI_HYDRA_TOPOLIB=

sleep 15

cd /home/nx01/nx01/adrianj/IOR/gkfs_mnt/gkfs_mnt
srun -n 1 -N 1 --export="ALL" /bin/bash -c "LD_PRELOAD=${GKFS_PRLD} mkdir data"
srun -n 1 -N 1 --export="ALL" /bin/bash -c "LD_PRELOAD=${GKFS_PRLD} cd /home/nx01/nx01/adrianj/IOR/gkfs_mnt/gkfs_mnt; cp /home/nx01/nx01/adrianj/IOR/src/C/IOR ."
srun -n 1 -N 1 --export="ALL" /bin/bash -c "LD_PRELOAD=${GKFS_PRLD} cd /home/nx01/nx01/adrianj/IOR/gkfs_mnt/gkfs_mnt; cp /home/nx01/nx01/adrianj/IOR/test.script ."

export OMP_NUM_THREADS=1
export GKFS_HOSTS_FILE=${HOME}/${SLURM_JOB_ID}_GEKKOFS/gkfs_hosts.txt
echo ${GKFS_PRLD}
echo ${GKFS_HOSTS_FILE}
cat  ${GKFS_HOSTS_FILE}
srun -n 1 -N 1 --export="ALL" /bin/bash -c "LD_PRELOAD=${GKFS_PRLD} df -h /home/nx01/nx01/adrianj/IOR/gkfs_mnt/gkfs_mnt"
export LD_PRELOAD=${GKFS_PRLD}
srun -n 1  -N 1 echo $LD_PRELOAD
srun -n 1 -N 1 df -h /home/nx01/nx01/adrianj/IOR/gkfs_mnt/gkfs_mnt
srun -n 48 -N 1 --export="ALL" /bin/bash -c "LD_PRELOAD=${GKFS_PRLD} cd /home/nx01/nx01/adrianj/IOR/gkfs_mnt/gkfs_mnt; /lustre/home/nx01/nx01/adrianj/IOR/gkfs_mnt/gkfs_mnt/IOR -vvv -b 2g -f /lustre/home/nx01/nx01/adrianj/IOR/gkfs_mnt/gkfs_mnt/test.script"


