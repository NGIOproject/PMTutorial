#!/bin/bash
#SBATCH -o streams.%A.out
#SBATCH -e streams.%A.err
#SBATCH -J streams
#SBATCH --nodes=1
#SBATCH --tasks-per-node=48
#SBATCH --time=0:10:0
#SBATCH --nvram-option=1LM:1000

export I_MPI_DEBUG=5
export I_MPI_HYDRA_TOPOLIB=

export PSM2_MULTI_EP=1

export PSM2_DEVICES="self,hfi,shm"
export PSM2_MULTIRAIL=1
export PSM2_MULTIRAIL_MAP=0:1,1:1

cd ~/streams

module load pmdk

NODES=1
CORES_PER_NODE=48
TOTAL_CORES=$((NODES*CORES_PER_NODE))
THREADS=1
PROCESSES=0
PPN=0
ulimit -c unlimited
export KMP_AFFINITY=granularity=core,compact,1

for THREADS in 1;
do
  PROCESSES=$((TOTAL_CORES/THREADS))
  PPN=$((PROCESSES/NODES))
  echo $NODES "Nodes"
  echo $PROCESSES "MPI processes, each with " $THREADS "OpenMPI threads"
  echo $PPN " MPI processes per node"
  export OMP_NUM_THREADS=$THREADS
  mpirun -n $PROCESSES --ppn $PPN ./distributed_streams 1

done


