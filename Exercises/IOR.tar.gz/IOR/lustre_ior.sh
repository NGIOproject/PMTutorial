#!/bin/bash

#SBATCH --nodes=1
#SBATCH --time=00:20:00
#SBATCH --job-name=lustre_ior
#SBATCH --nvram-option=1LM:1000
#SBATCH -o lustre_ior.%A.out
#SBATCH -e lustre_ior.%A.err


export PSM2_MULTIRAIL=1
export PSM2_MULTIRAIL_MAP=0:1,1:1
export PSM2_MULTI_EP=1
export PSM2_DEVICES="self,hfi,shm"
export I_MPI_HYDRA_TOPOLIB=

cd /home/nx04/nx04/$USER/IOR/

export OMP_NUM_THREADS=1

cp test.script.easy.lustre test.script

mkdir data

mpirun -n 48 -ppn 48 /lustre/home/nx04/nx04/$USER/IOR/src/C/IOR -vvv -b 2g -f /lustre/home/nx04/nx04/$USER/IOR/test.script

rm -fr data/*

